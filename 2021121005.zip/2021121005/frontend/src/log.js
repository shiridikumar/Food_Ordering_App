export default {
    logged:0
}