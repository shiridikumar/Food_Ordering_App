# Food Ordering App with MERN stack 
## Design and analysis of software systems
***
- How to run the code?
    - Firstly go to the backend directory and then run npm start in terminal
        - cd backend
        - npm install (to install the nod emodules)
        - npm start

    - cd into the frontend directory and then run npm start
        - cd frontend 
        - npm install (to install node modules)
        - npm start

-  Modules used:
    - bcryptjs
    - body-parser
    - cors
    - express
    - mongoose
    - multer
    - supervisor

***
2021121005
P Shiridi kumar
